$(document).ready(function(){

  $('#tab').mouseenter(function(){
    $('.doc').slideToggle();
  })

  $('#tab').click(function(){
    $('.doc').slideToggle();
  })
})
