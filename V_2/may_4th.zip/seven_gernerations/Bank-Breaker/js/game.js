$(document).ready(function(){

// $('#tab').mouseenter(function(){
//   var doc = $('.doc_wrapper');
//   if(doc.is(':visible')){
//     $('.doc').slideUp();
//   } else {
//     $('.doc').slideDown();
//   }
// })


  $('#tab').click(function(){
    $('.doc').slideToggle();
  })
})
